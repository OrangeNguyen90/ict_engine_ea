#ifndef ICT_DECISION_RENDERER_MQH
#define ICT_DECISION_RENDERER_MQH
#include "ICTDecisionEngine.mqh"
#include "ChartAnalysisRenderer.mqh"
#include "ICTDashboardPanel.mqh"
int g_ict_dashboard_page=0;
int g_ict_dashboard_x=-1,g_ict_dashboard_y=-1;
bool g_ict_dashboard_hidden=false;

string ICTBiasLabel(const int bias)
  { return bias>0 ? "BULLISH" : (bias<0 ? "BEARISH" : "NEUTRAL / UNKNOWN"); }
string ICTPriorityLabel(const SICTDecision &d)
  { return d.priority==ICT_PRIORITY_BUY ? "BUY PRIORITY" : (d.priority==ICT_PRIORITY_SELL ? "SELL PRIORITY" : "NO TRADE"); }
string ICTEvidenceLabel(const uint mask)
  { return ICTEvidenceText(mask); }
string ICTTimeLabel(const datetime value)
  { return value>0 ? TimeToString(value,TIME_DATE|TIME_MINUTES) : "unavailable"; }
string ICTPriceLabel(const double value)
  { return value>0 && MathIsValidNumber(value) ? DoubleToString(value,_Digits) : "unavailable"; }

// Wrap instead of silently truncating reasons. Chart resize recomputes geometry.
void ICTRenderDashboard(const string prefix,const SICTDecision &d,const string session,
                        const ENUM_BASE_CORNER corner,const int margin_x,const int margin_y,
                        const int requested_width,const int font_size,
                        const int requested_height=360,const bool show_market=true,
                        const bool show_ict=true,const bool show_plan=true)
  {
   string title="ICT DECISION | "+_Symbol+" | "+EnumToString(d.timeframe);
   string status=ICTPriorityLabel(d)+StringFormat(" | BUY %d | SELL %d",d.buy_score,d.sell_score);
   color status_ink=(d.priority==ICT_PRIORITY_BUY ? C'105,218,154' :
                     (d.priority==ICT_PRIORITY_SELL ? C'247,135,140' : C'250,201,91'));
   string body="[STATUS]\n";
   body+=(d.priority==ICT_PRIORITY_WAIT ? "No actionable priority" :
           (d.strong_signal ? "STRONG PRIORITY" : "MODERATE PRIORITY"))+" | "+
           (d.entry_confirmed ? "ENTRY CONFIRMED (advisory)" : "ENTRY NOT CONFIRMED")+"\n";
   body+="Bias: "+ICTBiasLabel(d.higher_bias)+" | State: "+ICTStateText(d.state)+"\n";
   if(show_market) {
   body+="[MARKET]\n";
   body+="MN / W / D: "+ICTBiasLabel(d.monthly_bias)+" / "+ICTBiasLabel(d.weekly_bias)+" / "+ICTBiasLabel(d.daily_bias)+"\n";
   body+="HTF / Structure: "+ICTBiasLabel(d.higher_bias)+" / "+ICTBiasLabel(d.structure_bias)+"\n";
   body+="Dealing range: "+ICTPriceLabel(d.dealing_low)+" - "+ICTPriceLabel(d.dealing_high)+
          " | EQ "+ICTPriceLabel(d.equilibrium)+" | "+d.price_location+"\n";
   body+="Session: "+session+" (New York; explicit UTC conversion)\n";
   }
   if(show_ict) {
   body+="[ICT EVIDENCE]\n";
   body+="Required: "+ICTEvidenceLabel(d.required)+"\n";
   body+="BUY confirmed: "+ICTEvidenceLabel(d.buy_confirmed)+"\n";
   body+="BUY missing: "+ICTEvidenceLabel(d.required & ~d.buy_confirmed)+"\n";
   body+="SELL confirmed: "+ICTEvidenceLabel(d.sell_confirmed)+"\n";
   body+="SELL missing: "+ICTEvidenceLabel(d.required & ~d.sell_confirmed)+"\n";
   body+="Sweep: "+ICTTimeLabel(d.sweep_time)+" | MSS: "+ICTTimeLabel(d.mss_time)+"\nFVG: "+ICTTimeLabel(d.fvg_time)+"\n";
   body+="SMT: "+(d.optional_data_notes!="" ? d.optional_data_notes : "Confirmed directional evidence; see side masks")+"\n";
   }
   body+="[DECISION DETAILS]\nReason: "+d.reason+"\nHard filters: "+(d.hard_filters_passed ? "PASS" : d.hard_filter_reason)+"\n";
   body+="Data quality: "+d.data_quality+"\n";
   if(d.invalidation!="") body+="Invalidation: "+d.invalidation+"\n";
   if(show_plan) {
   body+="[TRADE PLAN]\n";
   body+="DOL: "+d.dol_name+" "+ICTPriceLabel(d.dol)+" | FVG CE: "+ICTPriceLabel(d.consequent_encroachment)+"\n";
   bool ready=d.state==ICT_ENTRY_READY && d.hard_filters_passed && d.risk.valid;
   body+="Entry zone: "+ICTPriceLabel(d.zone_low)+" - "+ICTPriceLabel(d.zone_high)+"\n";
   body+="Entry: "+(ready ? ICTPriceLabel(d.entry) : "unavailable")+" | SL: "+(ready ? ICTPriceLabel(d.stop) : "unavailable")+" | TP1: "+(ready ? ICTPriceLabel(d.target) : "unavailable")+"\n";
   body+="TP2: "+(ready ? ICTPriceLabel(d.target2)+" "+d.target2_name : "unavailable")+"\n";
   if(ready && _Point>0) body+=StringFormat("SL distance: %.1f points\n",MathAbs(d.entry-d.stop)/_Point);
   body+=(ready ? StringFormat("RR %.2f | Lots %.4f | Risk %.2f | Reward %.2f %s",d.risk.rr,d.risk.volume,d.risk.risk_money,d.risk.reward_money,AccountInfoString(ACCOUNT_CURRENCY)) : "RR / lots / money: unavailable until entry and risk gates pass")+"\n";
   body+=StringFormat("Portfolio stop exposure %.2f %s | Unknown stops %d | Aligned %d\n",d.portfolio_stop_risk,AccountInfoString(ACCOUNT_CURRENCY),d.portfolio_unknown_stops,d.correlated_positions);
   }
   body+="Closed bar: "+ICTTimeLabel(d.as_of)+" | Refreshed: "+ICTTimeLabel(TimeLocal())+" local\n";
   body+="Context scores are not probabilities. Advisory only; no order execution.\nOverlays are independent context, not entry approval.";
   ICTRenderPagedPanel(prefix,title,status,status_ink,body,corner,margin_x,margin_y,
      requested_width,requested_height,font_size,g_ict_dashboard_page,
      g_ict_dashboard_x,g_ict_dashboard_y,g_ict_dashboard_hidden);
  }
#endif
