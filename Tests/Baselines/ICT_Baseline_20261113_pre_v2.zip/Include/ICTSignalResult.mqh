#ifndef ICT_SIGNAL_RESULT_MQH
#define ICT_SIGNAL_RESULT_MQH
#include "ICTTimeframeMapper.mqh"

enum ENUM_ICT_SIGNAL_STATE { ICT_SIGNAL_NO_TRADE=0, ICT_SIGNAL_WATCH_BUY=1,
   ICT_SIGNAL_WATCH_SELL=2, ICT_SIGNAL_BUY_CONFIRMED=3, ICT_SIGNAL_SELL_CONFIRMED=4 };
struct SICTSignalResult
  {
   string id,symbol,reason,htf_reason,mtf_reason,ltf_reason,smt_reason;
   string source_pool_id,target_pool_id,target2_pool_id,liquidity_event;
   SICTTimeframes frames;
   ENUM_ICT_SIGNAL_STATE state;
   datetime asof,trigger_bar,confirmation_time,source_event_time;
   int direction,score;
   bool data_ready,htf_pass,mtf_pass,ltf_pass,smt_required,smt_pass,risk_pass,confirmed;
   double entry,stop,tp1,tp2,rr,source_price;
  };
string ICTSignalStateText(const ENUM_ICT_SIGNAL_STATE state)
  {
   if(state==ICT_SIGNAL_BUY_CONFIRMED) return "BUY_CONFIRMED";
   if(state==ICT_SIGNAL_SELL_CONFIRMED) return "SELL_CONFIRMED";
   if(state==ICT_SIGNAL_WATCH_BUY) return "WATCH_BUY";
   if(state==ICT_SIGNAL_WATCH_SELL) return "WATCH_SELL";
   return "NO_TRADE";
  }
bool ICTSignalPlanValid(const SICTSignalResult &s,const double minimum_rr)
  {
   if((s.direction!=1 && s.direction!=-1) || !MathIsValidNumber(minimum_rr) || minimum_rr<2 ||
      !MathIsValidNumber(s.entry) || !MathIsValidNumber(s.stop) || !MathIsValidNumber(s.tp1) ||
      !MathIsValidNumber(s.rr) || s.entry<=0 || s.stop<=0 || s.tp1<=0 ||
      (s.entry-s.stop)*s.direction<=0 || (s.tp1-s.entry)*s.direction<=0) return false;
   double gross=MathAbs(s.tp1-s.entry)/MathAbs(s.entry-s.stop);
   return s.rr+1e-9>=minimum_rr && gross+1e-9>=minimum_rr && s.rr<=gross+1e-9;
  }
// No score can override a missing tier/trigger, target, SMT veto or risk gate.
bool ICTEvaluateSignal(SICTSignalResult &s,const double minimum_rr)
  {
   s.confirmed=false; s.state=ICT_SIGNAL_NO_TRADE; s.confirmation_time=0;
   s.id=s.symbol+"|"+IntegerToString((int)s.frames.ltf)+"|"+IntegerToString((long)s.trigger_bar)+"|"+IntegerToString(s.direction);
   if(!s.data_ready || s.frames.status!=ICT_MTF_FULL)
     { s.reason="DATA INSUFFICIENT: three closed timeframe tiers required"; return false; }
   if((s.direction!=1 && s.direction!=-1) || !s.htf_pass || !s.mtf_pass)
     { s.reason="NO_TRADE: HTF bias / MTF setup conflict or missing"; return false; }
   if(!s.ltf_pass || s.trigger_bar<=0 || s.asof<=s.trigger_bar || s.source_event_time>s.asof)
     {
      s.state=(s.direction>0 ? ICT_SIGNAL_WATCH_BUY : ICT_SIGNAL_WATCH_SELL);
      s.reason="WATCH: waiting for a valid closed LTF trigger"; return false;
     }
   if(s.smt_required && !s.smt_pass)
     { s.reason="NO_TRADE: required SMT unavailable, conflicting or unaligned"; return false; }
   if(s.tp1<=0 || s.target_pool_id=="")
     { s.reason="TARGET UNAVAILABLE"; return false; }
   if(!s.risk_pass || !ICTSignalPlanValid(s,minimum_rr))
     { s.reason="RISK FILTER FAIL: invalid plan or net RR below configured minimum"; return false; }
   s.state=(s.direction>0 ? ICT_SIGNAL_BUY_CONFIRMED : ICT_SIGNAL_SELL_CONFIRMED);
   s.confirmed=true; s.confirmation_time=s.asof;
   s.reason=s.htf_reason+" / "+s.mtf_reason+" / "+s.ltf_reason;
   return true;
  }
bool ICTSignalInsideWindow(const SICTSignalResult &s,const datetime oldest_bar,const datetime latest_close)
  {
   return s.confirmed && s.trigger_bar>=oldest_bar && s.confirmation_time<=latest_close &&
      s.confirmation_time>s.trigger_bar;
  }
// Append-only within the retention window. A recalculation cannot overwrite a
// previously committed candle, even with another ID/direction or changed prices.
bool ICTMergeConfirmedSignal(const SICTSignalResult &s,SICTSignalResult &history[],const int maximum)
  {
   if(!s.confirmed || s.id=="" || maximum<1 || s.confirmation_time<=s.trigger_bar) return false;
   for(int i=0;i<ArraySize(history);i++)
      if(history[i].id==s.id || (history[i].symbol==s.symbol && history[i].frames.ltf==s.frames.ltf &&
                              history[i].trigger_bar==s.trigger_bar)) return false;
   int n=ArraySize(history);
   if(n>=maximum) return false; // Never silently replace in-window confirmations.
   ArrayResize(history,n+1); history[n]=s; return true;
  }
#endif
