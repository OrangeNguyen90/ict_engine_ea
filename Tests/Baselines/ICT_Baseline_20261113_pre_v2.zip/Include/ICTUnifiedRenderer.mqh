#ifndef ICT_UNIFIED_RENDERER_MQH
#define ICT_UNIFIED_RENDERER_MQH
#include "ICTUnifiedInputs.mqh"
#include "DashboardComponents.mqh"
#include "ICTDashboardPanel.mqh"

string ICTUnifiedTF(const ENUM_TIMEFRAMES tf)
  { if(tf==PERIOD_CURRENT) return "N/A"; string value=EnumToString(tf); StringReplace(value,"PERIOD_",""); return value; }
string ICTUnifiedBias(const SICTTierSnapshot &tier)
  {
   if(tier.timeframe==PERIOD_CURRENT) return "N/A";
   if(tier.status==ICT_CONTEXT_INSUFFICIENT) return "INSUFFICIENT_DATA";
   return tier.status==ICT_CONTEXT_BULLISH ? "BULLISH" : tier.status==ICT_CONTEXT_BEARISH ? "BEARISH" : "NEUTRAL";
  }
string ICTUnifiedStructureText(const ENUM_ICT_MTF_STRUCTURE state)
  {
   string names[]={"INSUFFICIENT_DATA","ALIGNED","COUNTER-TREND","TRANSITION","NEUTRAL"};
   return (int)state>=0 && (int)state<5 ? names[(int)state] : "INSUFFICIENT_DATA";
  }
bool ICTShowSourceTier(const SICTUnifiedSnapshot &s,const ENUM_TIMEFRAMES tf)
  {
   return tf==s.frames.ltf ? Context_ShowLTF : tf==s.frames.mtf ? Context_ShowMTF :
      tf==s.frames.htf ? Context_ShowHTF : true;
  }
void ICTKeepObject(string &keep[],const string name)
  { int n=ArraySize(keep); ArrayResize(keep,n+1); keep[n]=name; }
void ICTReconcileObjects(const string prefix,const string &keep[])
  {
   for(int i=ObjectsTotal(0,0,-1)-1;i>=0;i--)
     {
      string name=ObjectName(0,i,0,-1); if(StringFind(name,prefix)!=0) continue;
      bool exists=false; for(int j=0;j<ArraySize(keep);j++) if(keep[j]==name) { exists=true; break; }
      if(!exists) ObjectDelete(0,name);
     }
  }
void ICTFiniteLine(const string name,const datetime first,const datetime last,const double price,
                    const color ink,const ENUM_LINE_STYLE style=STYLE_DOT)
  {
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_TREND,0,first,price,last,price);
   ObjectMove(0,name,0,first,price); ObjectMove(0,name,1,last,price);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ink); ObjectSetInteger(0,name,OBJPROP_STYLE,style);
   ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false); ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
  }
datetime ICTVisualEdge(const ENUM_TIMEFRAMES tf,const datetime from,const int bars)
  {
   datetime edge=from;
   for(int i=0;i<bars;i++) { datetime next=ICTBarClose(tf,edge); if(next<=edge) break; edge=next; }
   return edge;
  }
void ICTRenderUnifiedOverlays(const string prefix,const SICTUnifiedSnapshot &s,
                              const bool show_smt=true,const bool show_ob=true,const bool show_fvg=true,
                              const bool show_bpr=true,const bool show_pd=true,const bool show_structure=true,
                              const bool show_liquidity=true)
  {
   string keep[];
   if(!s.valid)
     {
      // Missing live context must not erase already confirmed SMT history.
      for(int i=ObjectsTotal(0,0,-1)-1;i>=0;i--)
        {
         string name=ObjectName(0,i,0,-1);
         if(StringFind(name,prefix+"smt_")==0) ICTKeepObject(keep,name);
        }
      ICTReconcileObjects(prefix,keep); return;
     }
   double tick=SymbolInfoDouble(s.symbol,SYMBOL_TRADE_TICK_SIZE);
   datetime context_edge=ICTVisualEdge(s.chart_tf,s.asof,OB_ExtendBars);
   for(int tier=0;tier<3;tier++)
     {
      string id=prefix+"context_"+IntegerToString(tier);
      SICTTierSnapshot t=s.tiers[tier];
      if(t.timeframe==PERIOD_CURRENT || !ICTShowSourceTier(s,t.timeframe)) continue;
      SMarketStructure context=t.structure;
      if(show_pd && context.recent_high>context.recent_low && context.recent_low>0)
        {
         datetime formed=(datetime)MathMax(context.recent_high_confirmed_time,context.recent_low_confirmed_time);
         if(formed>0 && formed<=s.asof)
           {
            double midpoint=(context.recent_high+context.recent_low)*0.5;
            RMContextZone(id+"premium",formed,context_edge,midpoint,context.recent_high,C'244,209,214');
            RMContextZone(id+"discount",formed,context_edge,context.recent_low,midpoint,C'206,238,211');
            ICTKeepObject(keep,id+"premium"); ICTKeepObject(keep,id+"discount");
            RMContextMarker(id+"pd_p",formed,(midpoint+context.recent_high)*0.5,"PREMIUM | "+ICTUnifiedTF(t.timeframe),clrMaroon);
            RMContextMarker(id+"pd_d",formed,(midpoint+context.recent_low)*0.5,"DISCOUNT | "+ICTUnifiedTF(t.timeframe),clrDarkGreen);
            ICTKeepObject(keep,id+"pd_p"); ICTKeepObject(keep,id+"pd_d");
           }
        }
      if(show_liquidity && context.recent_high_confirmed_time>0 && context.recent_high_confirmed_time<=s.asof &&
         context.recent_low_confirmed_time>0 && context.recent_low_confirmed_time<=s.asof)
        {
         ICTFiniteLine(id+"bsl",context.recent_high_confirmed_time,context_edge,context.recent_high,clrDarkOrange);
         ICTFiniteLine(id+"ssl",context.recent_low_confirmed_time,context_edge,context.recent_low,clrDeepSkyBlue);
         ObjectSetString(0,id+"bsl",OBJPROP_TOOLTIP,s.symbol+" | "+ICTUnifiedTF(t.timeframe)+" BSL | CONFIRMED | "+
            TimeToString(context.recent_high_confirmed_time,TIME_DATE|TIME_MINUTES));
         ObjectSetString(0,id+"ssl",OBJPROP_TOOLTIP,s.symbol+" | "+ICTUnifiedTF(t.timeframe)+" SSL | CONFIRMED | "+
            TimeToString(context.recent_low_confirmed_time,TIME_DATE|TIME_MINUTES));
         ICTKeepObject(keep,id+"bsl"); ICTKeepObject(keep,id+"ssl");
        }
      if(show_fvg && t.fvg_ready && t.gap.status<=SRMP_FVG_PARTIALLY_FILLED)
        {
         RMContextZone(id+"f",t.gap.formed_time,context_edge,t.gap.lower,t.gap.upper,C'153,184,227');
         RMContextMarker(id+"ft",ICTBarClose(t.timeframe,t.gap.formed_time),t.gap.upper,
            ICTUnifiedTF(t.timeframe)+" "+(t.gap.direction>0 ? "BULL FVG" : "BEAR FVG"),clrRoyalBlue);
         ICTKeepObject(keep,id+"f"); ICTKeepObject(keep,id+"ft");
        }
      if(show_bpr && t.bpr_ready)
        {
         RMContextZone(id+"b",t.bpr.confirmed_at,context_edge,t.bpr.lower,t.bpr.upper,t.bpr.direction>0 ? C'145,206,185' : C'222,169,187');
         RMContextMarker(id+"bt",t.bpr.confirmed_at,t.bpr.upper,
            ICTUnifiedTF(t.timeframe)+" "+(t.bpr.direction>0 ? "BULL BPR" : "BEAR BPR"),t.bpr.direction>0 ? clrDarkGreen : clrMaroon);
         ICTKeepObject(keep,id+"b"); ICTKeepObject(keep,id+"bt");
        }
      if(show_structure && t.structure.bos_time>0)
        {
         RMContextMarker(id+"ms",ICTBarClose(t.timeframe,t.structure.bos_time),t.structure.bos_level,
            (t.structure.mss ? "MSS | " : "BOS | ")+ICTUnifiedTF(t.timeframe),clrDarkCyan);
         ObjectSetString(0,id+"ms",OBJPROP_TOOLTIP,"Confirmed at "+TimeToString(ICTBarClose(t.timeframe,t.structure.bos_time),TIME_DATE|TIME_MINUTES));
         ICTKeepObject(keep,id+"ms");
        }
     }
   for(int i=0;i<s.event_count && show_smt;i++)
     {
      SICTSMTEvent e=s.events[i]; ENUM_TIMEFRAMES tf=e.signal.timeframe;
      bool enabled=(tf==s.frames.ltf ? SMT_ShowLTF : tf==s.frames.mtf ? SMT_ShowMTF : tf==s.frames.htf ? SMT_ShowHTF : SMT_ShowCurrentChart);
      if(!enabled || e.signal.confirmation_time<=0 || e.seed_context ||
         !ICTSMTInsideDisplayWindow(e.signal.confirmation_time,s.display_start,s.asof)) continue;
      string line=prefix+"smt_"+IntegerToString((long)ICTStableHash(e.signal.event_id)),label=line+"t";
      if(ObjectFind(0,line)<0) ObjectCreate(0,line,OBJ_TREND,0,e.signal.primary_prior_time,e.signal.primary_prior,
                                          e.signal.primary_pivot_time,e.signal.primary_recent);
      ObjectMove(0,line,0,e.signal.primary_prior_time,e.signal.primary_prior);
      ObjectMove(0,line,1,e.signal.primary_pivot_time,e.signal.primary_recent);
      color ink=e.signal.direction>0 ? clrSeaGreen : clrCrimson;
      ObjectSetInteger(0,line,OBJPROP_COLOR,ink); ObjectSetInteger(0,line,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(0,line,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,line,OBJPROP_WIDTH,tf==s.frames.htf ? 3 : 1);
      ObjectSetInteger(0,line,OBJPROP_STYLE,tf==s.frames.mtf ? STYLE_DASH : STYLE_SOLID);
      string text="SMT "+(e.signal.direction>0 ? "BULL" : "BEAR")+" | "+ICTUnifiedTF(tf)+" | "+e.signal.comparison;
      string tooltip=text+" | relation "+(e.signal.relation>0 ? "POSITIVE" : "INVERSE")+
         " | source "+(e.signal.comparator_extreme ? "COMPARATOR EXTREME" : "PRIMARY EXTREME")+
         " | pivot "+TimeToString(e.signal.primary_pivot_time,TIME_DATE|TIME_MINUTES)+
         " | confirmed "+TimeToString(e.signal.confirmation_time,TIME_DATE|TIME_MINUTES);
      ObjectSetString(0,line,OBJPROP_TOOLTIP,tooltip);
      double offset=tick*(12+(i%3)*12)*(e.signal.direction>0 ? -1 : 1);
      RMContextMarker(label,e.signal.confirmation_time,e.signal.primary_recent+offset,text,ink);
      ObjectSetString(0,label,OBJPROP_TOOLTIP,tooltip);
      ICTKeepObject(keep,line); ICTKeepObject(keep,label);
     }
   double price=SymbolInfoDouble(s.symbol,SYMBOL_BID);
   bool selected[ICT_SMART_OB_MAX]; ArrayInitialize(selected,false);
   datetime edge=ICTVisualEdge(s.chart_tf,s.asof,OB_ExtendBars);
   for(int drawn=0;drawn<OB_MaxVisibleZones && show_ob && EnableAutoOB;drawn++)
     {
      int best=-1; double rank=-DBL_MAX;
      for(int i=0;i<s.ob_count;i++)
        {
         SICTStrongOrderBlock z=s.zones[i];
         if(selected[i] || !ICTShowSourceTier(s,z.timeframe) || z.confirmation_score<OB_MinStrengthToDraw ||
            (EnableStrongOBOnly && z.grade!=ICT_OB_STRONG) ||
            (!OB_ShowMitigated && z.life==ICT_OB_MITIGATED) ||
            (!OB_ShowInvalidated && (z.life==ICT_OB_INVALIDATED || z.life==ICT_OB_EXPIRED))) continue;
         double distance=(price>0 && tick>0 ? MathAbs(z.ob.midpoint-price)/tick : 0);
         double value=(ICTOBActive(z) ? 10000000 : 0)+(int)z.grade*1000000+z.confirmation_score*1000-MathMin(999.0,distance);
         if(best<0 || value>rank) { best=i; rank=value; }
        }
      if(best<0) break; selected[best]=true;
      SICTStrongOrderBlock z=s.zones[best];
      string name=prefix+"ob_"+IntegerToString((long)ICTStableHash(z.id));
      color ink=(z.grade==ICT_OB_STRONG ? (z.ob.direction>0 ? OB_StrongBullColor : OB_StrongBearColor) :
                 z.grade==ICT_OB_MEDIUM ? (z.ob.direction>0 ? OB_MediumBullColor : OB_MediumBearColor) : OB_WeakColor);
      bool inactive=z.life==ICT_OB_MITIGATED || z.life==ICT_OB_INVALIDATED || z.life==ICT_OB_EXPIRED;
      if(inactive) ink=clrSlateGray;
      RMContextZone(name,z.ob.formation_time,edge,z.ob.lower,z.ob.upper,ink);
      ObjectSetInteger(0,name,OBJPROP_FILL,!inactive);
      ObjectSetInteger(0,name,OBJPROP_STYLE,inactive ? STYLE_DASH : STYLE_SOLID);
      string title=ICTUnifiedTF(z.timeframe)+" "+(z.ob.direction>0 ? "BULL " : "BEAR ")+ICTOBGradeText(z.grade)+" OB"+
         (OB_ShowStrengthScore ? " | "+IntegerToString(z.confirmation_score)+"/100" : "")+" | "+ICTOBLifeText(z.life);
      string details=title+" | Displacement="+(z.ob.displacement ? "PASS" : "FAIL")+
         " BOS/MSS="+(z.ob.break_confirmed ? "PASS" : "FAIL")+" FVG/BPR="+(z.ob.fvg ? "FVG" : "N/A")+
         " Sweep="+(z.ob.liquidity_sweep ? "YES" : "NO")+" HTF Alignment="+(z.bias_points>0 ? "PASS" : "N/A")+
         " Freshness="+ICTOBLifeText(z.life)+" current score="+IntegerToString(z.current_context_score)+
         " | "+IntegerToString(z.candles)+" candles | sweep #"+IntegerToString(z.sweep_count)+
         " | touches "+IntegerToString(z.touch_count)+" | mitigation "+DoubleToString(z.mitigation_depth*100,1)+"% | "+z.gate_reason+
         " | formed "+TimeToString(z.ob.formation_time,TIME_DATE|TIME_MINUTES)+
         " | confirmed "+TimeToString(z.ob.confirmation_time,TIME_DATE|TIME_MINUTES);
      ObjectSetString(0,name,OBJPROP_TOOLTIP,details); ICTKeepObject(keep,name);
      if(OB_ShowMidline) { ICTFiniteLine(name+"m",z.ob.formation_time,edge,z.ob.midpoint,ink); ICTKeepObject(keep,name+"m"); }
      if(OB_ShowOpenReference) { ICTFiniteLine(name+"o",z.ob.formation_time,edge,z.open_reference,ink); ICTKeepObject(keep,name+"o"); }
      RMContextMarker(name+"t",z.ob.confirmation_time,z.ob.upper+tick*(drawn%3)*10,title,ink);
      ObjectSetString(0,name+"t",OBJPROP_TOOLTIP,details); ICTKeepObject(keep,name+"t");
     }
   ICTReconcileObjects(prefix,keep);
  }

string ICTStrongOBDetails(const SICTStrongOrderBlock &z)
  {
   return ICTUnifiedTF(z.timeframe)+" "+(z.ob.direction>0 ? "BULL " : "BEAR ")+ICTOBGradeText(z.grade)+" "+
      IntegerToString(z.confirmation_score)+"/100 | "+ICTOBLifeText(z.life)+
      "\nZone "+DoubleToString(z.ob.lower,_Digits)+" - "+DoubleToString(z.ob.upper,_Digits)+
      " | touches "+IntegerToString(z.touch_count)+" | depth "+DoubleToString(z.mitigation_depth*100,1)+"%"+
      "\nSweep "+IntegerToString(z.sweep_points)+" Disp "+IntegerToString(z.displacement_points)+
      " Structure "+IntegerToString(z.structure_points)+" FVG "+IntegerToString(z.fvg_points)+
      " Bias "+IntegerToString(z.bias_points)+" PD "+IntegerToString(z.pd_points)+" Fresh "+IntegerToString(z.freshness_points)+
      "\n"+z.gate_reason+(z.invalidation_reason!="" ? " | "+z.invalidation_reason : "");
  }
string ICTUnifiedDashboardBody(const SICTUnifiedSnapshot &s,const string decision,const string plan,const string reason)
  {
   string body="[THREE-TIER CONTEXT]\nMode: "+(s.frames.mode==ICT_MTF_AUTO ? "AUTO" : "MANUAL")+
      " | "+(s.frames.status==ICT_MTF_FULL ? "3 tiers" : s.frames.status==ICT_MTF_TWO_TIER ? "2 tiers" : "1 tier")+"\n";
   string tier_names[3]={"LTF","MTF","HTF"};
   for(int i=0;i<3;i++) body+=tier_names[i]+" "+ICTUnifiedTF(s.tiers[i].timeframe)+" "+ICTUnifiedBias(s.tiers[i])+
      (s.tiers[i].closed_at>0 ? " | close "+TimeToString(s.tiers[i].closed_at,TIME_DATE|TIME_MINUTES) : "")+"\n";
   body+="MTF: "+ICTUnifiedStructureText(s.mtf_state)+"\n"+s.reason+"\n[HTF / MTF / LTF DECISION]\n";
   SICTSignalResult signal=s.signal;
   bool shared=signal.symbol==s.symbol && signal.asof==s.asof && signal.asof>0;
   if(shared)
     {
      body+=ICTSignalStateText(signal.state)+" | "+TimeToString(signal.asof,TIME_DATE|TIME_MINUTES)+"\n";
      body+="HTF "+(signal.htf_pass ? "PASS" : "FAIL")+" / MTF "+(signal.mtf_pass ? "PASS" : "FAIL")+
         " / LTF "+(signal.ltf_pass ? "PASS" : "WAIT")+" / Risk "+(signal.risk_pass ? "PASS" : "FAIL")+"\n";
      body+="Quality "+IntegerToString(signal.score)+"/100 (weighted evidence, not a probability)\n";
      body+=signal.htf_reason+"\n"+signal.mtf_reason+"\n"+signal.ltf_reason+"\n"+signal.reason+"\n";
      if(signal.id!="") body+="ID "+signal.id+"\n";
     }
   else body+=decision+"\n"+reason+"\n";
   body+="[SMT ANALYSIS]\n";
   body+="SMT 1: "+(s.comparison1=="" ? "DISABLED / UNAVAILABLE" : s.comparison1)+
      " | SMT 2: "+(s.comparison2=="" ? "DISABLED / UNAVAILABLE" : s.comparison2)+"\n";
   if(s.comparator_reason!="") body+=s.comparator_reason+"\n";
   body+="Current chart "+ICTUnifiedTF(s.chart_tf)+" | detection: "+IntegerToString(s.detection_bars)+" bars of EACH TF | display: "+IntegerToString(s.display_bars)+" CHART bars\n";
   for(int layer=0;layer<s.layer_count;layer++)
     {
      SICTSMTLayer l=s.layers[layer];
      body+=ICTUnifiedTF(l.timeframe)+(l.timeframe==s.chart_tf ? " @Current Chart" : "")+" detected "+IntegerToString(l.detected)+" | in chart window "+IntegerToString(l.displayed)+
         " | bull/bear active "+IntegerToString(l.bullish)+"/"+IntegerToString(l.bearish)+" | "+l.reason+"\n";
      for(int peer=0;peer<2;peer++)
        {
         SICTSMTPeerSnapshot p=l.peers[peer];
         body+="Peer "+IntegerToString(peer+1)+" "+(p.comparison=="" ? "N/A" : p.comparison)+" | "+
            (p.relation_known ? (p.relation>0 ? "+ POSITIVE" : "- INVERSE") : "RELATION N/A")+
            " | "+ICTSMTPeerStateText(p.state)+(p.conflict ? " / SMT_CONFLICT" : "")+"\n";
         if(p.primary_pivot_time>0)
            body+="Pivot "+DoubleToString(p.primary_pivot,_Digits)+" @ "+TimeToString(p.primary_pivot_time,TIME_DATE|TIME_MINUTES)+
               " | confirmed "+TimeToString(p.confirmation_time,TIME_DATE|TIME_MINUTES)+"\n";
         body+=p.reason+"\n";
        }
     }
   if(shared) body+=signal.smt_reason+"\n";
   body+="[LIQUIDITY & BREAKOUT]\n";
   if(shared)
     {
      body+="Liquidity source: "+(signal.source_pool_id=="" ? "N/A" : signal.source_pool_id)+"\n";
      body+="Sweep/Breakout event: "+signal.liquidity_event+" "+(signal.source_event_time>0 ? TimeToString(signal.source_event_time,TIME_DATE|TIME_MINUTES) : "N/A")+"\n";
      body+="Pool target: "+(signal.target_pool_id=="" ? "TARGET UNAVAILABLE" : signal.target_pool_id)+"\n";
      body+="Distance to liquidity: "+(signal.tp1>0 && signal.entry>0 ? DoubleToString(MathAbs(signal.tp1-signal.entry),_Digits) : "N/A")+"\n";
     }
   else body+="N/A: no shared decision / liquidity plan\n";
   body+="BSL/SSL are inferred structural pools; OB/FVG/BPR are price objectives.\n[STRONG ORDER BLOCKS]\n";
   double price=SymbolInfoDouble(s.symbol,SYMBOL_BID),point=SymbolInfoDouble(s.symbol,SYMBOL_POINT);
   int nearest=ICTNearestActiveOB(s,price),bull=-1,bear=-1;
   for(int i=0;i<s.ob_count;i++)
     {
      if(!ICTOBActive(s.zones[i])) continue;
      if(s.zones[i].ob.direction>0 && (bull<0 || s.zones[i].confirmation_score>s.zones[bull].confirmation_score)) bull=i;
      if(s.zones[i].ob.direction<0 && (bear<0 || s.zones[i].confirmation_score>s.zones[bear].confirmation_score)) bear=i;
     }
   if(nearest>=0)
     { body+="Nearest: "+ICTStrongOBDetails(s.zones[nearest])+"\n";
       if(price>0 && point>0) body+="Distance to midpoint "+DoubleToString(MathAbs(s.zones[nearest].ob.midpoint-price)/point,1)+" symbol points\n"; }
   else body+="No active OB with valid hard gates\n";
   if(bull>=0 && bull!=nearest) body+="Strongest bull: "+ICTStrongOBDetails(s.zones[bull])+"\n";
   if(bear>=0 && bear!=nearest) body+="Strongest bear: "+ICTStrongOBDetails(s.zones[bear])+"\n";
   body+="[TRADE PLAN & RISK]\n";
   if(shared)
     {
      body+="Entry "+(signal.entry>0 ? DoubleToString(signal.entry,_Digits) : "N/A")+
         " / SL "+(signal.stop>0 ? DoubleToString(signal.stop,_Digits) : "N/A")+"\n";
      body+="TP1 "+(signal.tp1>0 ? DoubleToString(signal.tp1,_Digits) : "TARGET UNAVAILABLE")+
         " / TP2 "+(signal.tp2>0 ? DoubleToString(signal.tp2,_Digits) : "N/A")+
         " / net RR "+(signal.rr>0 ? DoubleToString(signal.rr,2) : "N/A")+"\n";
      if(!signal.risk_pass && signal.ltf_pass) body+="RISK FILTER FAIL\n";
      if(signal.confirmed && reason!=signal.reason) body+="Live recheck: "+reason+"\n";
     }
   else body+=plan+"\n";
   body+="As-of "+TimeToString(s.asof,TIME_DATE|TIME_SECONDS)+" | data age "+IntegerToString((long)MathMax(0,TimeCurrent()-s.asof))+"s\n";
   body+="Rule scores are heuristic evidence, not win probabilities. Advisory only.";
   return body;
  }
void ICTRenderUnifiedDashboard(const string prefix,const SICTUnifiedSnapshot &s,const string decision,
                                const string plan,const string reason,const ENUM_BASE_CORNER corner,
                                const int x,const int y,const int width,const int height,const int font,
                                int &page,int &moved_x,int &moved_y,const bool hidden)
  {
   string title="ICT SMART | "+s.symbol+" | "+ICTUnifiedTF(s.frames.ltf)+" / "+ICTUnifiedTF(s.frames.mtf)+" / "+ICTUnifiedTF(s.frames.htf);
   ICTRenderPagedPanel(prefix,title,decision,s.valid ? clrGold : clrLightCoral,
      ICTUnifiedDashboardBody(s,decision,plan,reason),corner,x,y,width,height,font,page,moved_x,moved_y,hidden);
  }
#endif
