#property strict
#property description "Shared MTF, SMT and Strong OB deterministic fixtures. Never sends trade requests."
#include "../Include/ICTUnifiedBridge.mqh"
#include "../Include/ICTRangeEngine.mqh"
int failures=0,checks=0;
void Check(const string name,const bool value)
  { checks++; if(!value) failures++; Print(name,value ? " PASS" : " FAIL"); }
#include "ICTUnifiedCoreFixtures.mqh"
void TestSignalBridge()
  {
   SICTUnifiedSnapshot source; ZeroMemory(source); source.schema=ICT_UNIFIED_SCHEMA;
   SignalFixture(source.signal); ICTEvaluateSignal(source.signal,2);
   source.symbol=source.signal.symbol; source.frames=source.signal.frames; source.asof=source.signal.asof; source.chart_tf=PERIOD_M5;
   source.valid=true; source.capacity_ok=true; source.display_start=100000;
   source.comparison1="PEER1"; source.comparison2="PEER2";
   ENUM_TIMEFRAMES frames[3]={PERIOD_M5,PERIOD_H1,PERIOD_D1};
   datetime opens[3]={100000,96000,1000};
   for(int i=0;i<3;i++)
     {
      source.tiers[i].timeframe=frames[i]; source.tiers[i].status=ICT_CONTEXT_BULLISH;
      FixtureBar(source.tiers[i].last_bar,opens[i],99,102,98,101);
      source.tiers[i].closed_at=ICTBarClose(frames[i],opens[i]);
     }
   source.tiers[0].displacement_up=true;
   source.layer_count=1; source.layers[0].timeframe=PERIOD_M5; source.layers[0].last_close=source.asof;
   source.layers[0].peers[0].comparison="PEER1"; source.layers[0].peers[0].ready=true;
   source.layers[0].peers[0].relation_known=true; source.layers[0].peers[0].relation=1;
   source.layers[0].peers[0].state=ICT_SMT_PEER_BULLISH; source.layers[0].peers[0].last_close=source.asof;
   source.layers[0].peers[1].comparison="PEER2"; source.layers[0].peers[1].reason="DATA INSUFFICIENT";
   double values[]; string texts[]; SICTUnifiedSnapshot decoded;
   Check("central signal packs",ICTUnifiedPack(source,values,texts));
   Check("central signal bridge roundtrip",ICTUnifiedUnpack(values,texts,decoded) && decoded.signal.id==source.signal.id &&
      decoded.signal.entry==source.signal.entry && decoded.signal.confirmation_time==source.signal.confirmation_time &&
      decoded.tiers[0].last_bar.time==source.tiers[0].last_bar.time && decoded.tiers[0].displacement_up && decoded.chart_tf==PERIOD_M5);
   Check("bridge retains independent unavailable peer",decoded.layers[0].peers[0].state==ICT_SMT_PEER_BULLISH &&
      decoded.layers[0].peers[1].state==ICT_SMT_PEER_NA && decoded.layers[0].peers[1].reason=="DATA INSUFFICIENT");
   source.signal.ltf_pass=false; ICTUnifiedPack(source,values,texts);
   Check("bridge refuses confirmed label without LTF gate",!ICTUnifiedUnpack(values,texts,decoded));
   source.signal.ltf_pass=true; source.signal.asof++; ICTUnifiedPack(source,values,texts);
   Check("bridge refuses decision-context timestamp mismatch",!ICTUnifiedUnpack(values,texts,decoded));
   source.signal.asof--; ICTUnifiedPack(source,values,texts); ArrayResize(values,ArraySize(values)-1);
   Check("bridge rejects truncated snapshot",!ICTUnifiedUnpack(values,texts,decoded));
   SICTSMTEvent original; ZeroMemory(original); original.signal.comparison="PEER1";
   original.signal.timeframe=PERIOD_M5; original.signal.direction=1; original.signal.relation=1;
   original.signal.state=SRMP_SMT_BULLISH;
   original.signal.primary_prior_time=99000; original.signal.primary_pivot_time=99300;
   original.signal.comparison_prior_time=99000; original.signal.comparison_pivot_time=99600;
   original.signal.primary_prior=100; original.signal.primary_recent=95;
   original.signal.comparison_prior=100; original.signal.comparison_recent=101;
   original.signal.pivot_confirmation_time=100000; original.signal.confirmation_time=100300;
   original.signal.event_id="TEST|PEER1|"+IntegerToString((int)PERIOD_M5)+"|1|1|99000|99300|99000|99600";
   original.life=ICT_SMT_CONFIRMED; original.changed_at=100300;
   SICTSMTEvent restored; ICTPackSMTPayload(original,values);
   Check("SMT journal payload preserves original confirmation",ICTUnpackSMTPayload("TEST","PEER1",original.signal.event_id,values,100300,restored) &&
      restored.signal.confirmation_time==original.signal.confirmation_time && restored.signal.primary_pivot_time==99300 &&
      restored.signal.comparison_pivot_time==99600 && restored.signal.primary_recent==95);
   Check("SMT journal rejects identity corruption",!ICTUnpackSMTPayload("TEST","PEER1","BAD_ID",values,100300,restored));
   values[12]=100600;
   Check("SMT journal rejects future confirmation",!ICTUnpackSMTPayload("TEST","PEER1",original.signal.event_id,values,100300,restored));
   ICTPackSMTPayload(original,values); ArrayResize(values,ArraySize(values)-1);
   Check("SMT journal rejects truncated payload",!ICTUnpackSMTPayload("TEST","PEER1",original.signal.event_id,values,100300,restored));
  }
int OnInit()
  {
   RunUnifiedCoreFixtures();
   TestSignalBridge();
   PrintFormat("ICTUnifiedTests RESULT checks=%d failures=%d",checks,failures);
   return failures==0 ? INIT_SUCCEEDED : INIT_FAILED;
  }
double OnTester() { return failures; }
